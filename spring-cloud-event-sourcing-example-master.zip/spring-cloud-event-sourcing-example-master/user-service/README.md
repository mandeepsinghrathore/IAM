# User Service

The user service is responsible for being the authentication gateway for the online store application. Backend microservices that require authentication will attempt to authorize the user's session through this OAuth2 authorization server.