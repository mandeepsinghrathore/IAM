# Online Store Web

The online store web application is responsible for serving as the main user interface of the online store backend. Users are able to register, login, and order products using this interface.