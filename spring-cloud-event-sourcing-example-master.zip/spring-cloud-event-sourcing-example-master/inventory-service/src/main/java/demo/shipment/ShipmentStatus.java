package demo.shipment;

public enum ShipmentStatus {
    PENDING,
    SHIPPED,
    DELIVERED
}
