# Inventory Service

The inventory service is responsible for managing the inventory and product catalogs that are ordered on the online store.