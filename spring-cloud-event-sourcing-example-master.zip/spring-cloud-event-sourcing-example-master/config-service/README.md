# Config Service

The config service is responsible for distributing centralized external configurations for each service in the cluster.