# Discovery Service

The discovery service is responsible for maintaining a registry of service information in the cluster environment. Each service will register with this application when they start up in the cluster, and provide network information of where that service can be contacted.