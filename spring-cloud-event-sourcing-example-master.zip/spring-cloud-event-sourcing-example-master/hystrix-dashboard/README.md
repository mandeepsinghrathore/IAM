# Hystrix Dashboard

The hystrix dashboard is responsible for providing a dashboard that can be used to monitor circuit breakers in a microservice that exposes a hystrix stream endpoint.