# Edge Service

The edge service is responsible for securely exposing routes from multiple microservices to REST API consumers.