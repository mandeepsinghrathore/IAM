# Order Service

The order service is responsible for providing an API to facilitate the ordering of products that a user has purchased.