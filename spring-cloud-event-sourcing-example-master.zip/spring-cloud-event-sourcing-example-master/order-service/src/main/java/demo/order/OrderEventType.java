package demo.order;

public enum OrderEventType {
    PURCHASED,
    CREATED,
    ORDERED,
    SHIPPED,
    DELIVERED
}
