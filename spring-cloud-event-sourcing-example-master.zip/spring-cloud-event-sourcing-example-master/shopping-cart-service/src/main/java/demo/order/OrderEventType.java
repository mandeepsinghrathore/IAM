package demo.order;

public enum OrderEventType {
    CREATED,
    ORDERED,
    RESERVED,
    SHIPPED,
    DELIVERED
}
