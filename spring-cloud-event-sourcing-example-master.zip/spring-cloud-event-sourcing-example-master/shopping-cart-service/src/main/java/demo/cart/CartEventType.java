package demo.cart;

public enum CartEventType {
    ADD_ITEM,
    REMOVE_ITEM,
    CLEAR_CART,
    CHECKOUT
}