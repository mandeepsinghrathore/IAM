# Catalog Service

The catalog service is responsible for retrieving the active catalog of products for the online store. 