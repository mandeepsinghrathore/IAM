DELETE FROM catalog_info;
INSERT INTO catalog_info VALUES (0, 1, 0);