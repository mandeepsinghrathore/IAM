package demo.api.v1;

import demo.product.Product;
import org.springframework.hateoas.Resources;

public class ProductsResource extends Resources<Product> {
}
