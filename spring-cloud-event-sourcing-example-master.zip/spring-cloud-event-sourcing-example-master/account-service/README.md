# Account Service

The account service is responsible for storing the account information of a user.