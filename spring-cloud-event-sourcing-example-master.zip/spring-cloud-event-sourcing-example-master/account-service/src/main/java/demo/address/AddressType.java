package demo.address;

public enum AddressType {
    SHIPPING,
    BILLING
}
